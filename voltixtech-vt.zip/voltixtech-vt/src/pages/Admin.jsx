export default function Admin() {
  return (
    <div>
      <h1>Panel Administratora</h1>
      <button>Dodaj produkt</button>
      <button>Edytuj produkt</button>
    </div>
  );
}